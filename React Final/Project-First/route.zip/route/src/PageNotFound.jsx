import React from 'react'

function PageNotFound() {
  return (
    <div>
       <h1> Page Not Found Error : 404 </h1>
    </div>
  )
}

export default PageNotFound