import React from 'react'

function Categori() {
  return (
    <div>
        Category page

    </div>
  )
}

export default Categori