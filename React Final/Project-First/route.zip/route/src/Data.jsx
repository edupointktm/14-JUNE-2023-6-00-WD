 const Data=[
    {
        id:1,
        names:"Prakash Kunwar",
        Address:"Kathmandu",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Computer Engineers"
    },
    {
        id:2,
        names:"Hari Home",
        Address:"Kathmandu",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
    {
        id:3,
        names:"Bishal Thapa",
        Address:"Janakpur",
        Mobile_no:9874621411,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	  {
        id:4,
        names:"Rabi Kumar Sah",
        Address:"Janakpur",
        Mobile_no:98542145,
        Gender:"Male",
		Faculty:"Computer Engineers"
    },
	  {
        id:5,
        names:"Supriya shrestha",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
		{
        id:6,
        names:"Bipina Rai",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Computer Engineers"
    },
	{
        id:7,
        names:"Ghanand Yadav",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:8,
        names:"Pabitra Kumari Thakuri",
        Address:"Biratnagar",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Sita Pachhera",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Som Bhadur Tamang",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Ramesh K. C.",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Saroj Mainali",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Saraswati bam",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    },
	{
        id:9,
        names:"Samita Shrestha",
        Address:"Pokhara",
        Mobile_no:55454554,
        Gender:"Male",
		Faculty:"Electronics Engineers"
    }



]



export default Data