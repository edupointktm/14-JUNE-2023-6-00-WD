import React from 'react'

function About() {
  return (
    <div>
        <h1>About PAGE</h1>
        </div>
  )
}

export default About